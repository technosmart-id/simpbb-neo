-- MySQL dump 10.13  Distrib 9.6.0, for Win64 (x86_64)
--
-- Host: localhost    Database: simpbb_neo
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'b986f1f8-1dcc-11f1-a0a4-4c445b352757:1-3968';

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(36) NOT NULL,
  `account_id` text NOT NULL,
  `provider_id` text NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `access_token` text,
  `refresh_token` text,
  `id_token` text,
  `access_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `refresh_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `scope` text,
  `password` text,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_userId_idx` (`user_id`),
  CONSTRAINT `account_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('543865cf-603f-4c00-a96b-dd9ae1fdb111','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3','credential','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3',NULL,NULL,NULL,NULL,NULL,NULL,'df8d3b7f91490d1f295af0689af87509:c96376c9d608541f6b0d5baf33b288c1d14b490dfac093a997628242f786bbd7bfd22ba6f482da98190810c0a803b46a01b5669d7d210779884fde8400590b2d','2026-03-25 01:55:49.359','2026-03-25 01:55:49.616');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `akses`
--

DROP TABLE IF EXISTS `akses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `akses` (
  `AKSES` varchar(50) NOT NULL,
  `AKTIF` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`AKSES`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `akses`
--

LOCK TABLES `akses` WRITE;
/*!40000 ALTER TABLE `akses` DISABLE KEYS */;
/*!40000 ALTER TABLE `akses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `organization_id` varchar(36) DEFAULT NULL,
  `created_by_id` varchar(36) DEFAULT NULL,
  `cover_image` varchar(512) DEFAULT NULL,
  `attachment_file` varchar(512) DEFAULT NULL,
  `gallery_images` json DEFAULT NULL,
  `additional_documents` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `books_organization_id_idx` (`organization_id`),
  KEY `books_created_by_id_idx` (`created_by_id`),
  CONSTRAINT `books_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `casbin_rule`
--

DROP TABLE IF EXISTS `casbin_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `casbin_rule` (
  `id` varchar(36) NOT NULL,
  `ptype` varchar(255) NOT NULL,
  `v0` varchar(255) DEFAULT NULL,
  `v1` varchar(255) DEFAULT NULL,
  `v2` varchar(255) DEFAULT NULL,
  `v3` varchar(255) DEFAULT NULL,
  `v4` varchar(255) DEFAULT NULL,
  `v5` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casbin_rule`
--

LOCK TABLES `casbin_rule` WRITE;
/*!40000 ALTER TABLE `casbin_rule` DISABLE KEYS */;
INSERT INTO `casbin_rule` VALUES ('06056dec-ae86-4c10-8570-a74a92c92e82','p','global_user','files','read','','allow',NULL),('186d583e-126a-41a6-9de7-68cb79d63bce','p','global_admin','*','*','','allow',NULL),('1fe3c425-80ac-4430-ab09-60f5ec365960','p','global_user','files','delete','','allow',NULL),('30b203f8-a059-4e13-8a7d-05d99edb7bb5','p','user','books','update','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('3945dcd1-ae8f-4ca2-9ed9-0a6fdde28165','p','user','files','read','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('3d9c157c-7d1a-436e-ab1e-d9062a0b0433','p','user','files','create','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('425519d2-071e-40a7-bfea-bcdf2e0bb86a','p','global_user','files','update','','allow',NULL),('56a0c125-76c4-4028-a30b-4c8508106434','g','member:b926a194-97e3-49df-b866-5304f76409d2','owner','d39fd9a9-1477-4246-8370-a0e1625f3505',NULL,NULL,NULL),('62e3c465-6cfd-4dcd-a56f-6aabf409f901','p','owner','*','*','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('7cf6c0a5-5a34-43bc-bc12-0454cd589a88','p','global_user','books','read','','allow',NULL),('9a330b6f-1d4b-4dda-b1f6-ae3191a45403','p','global_user','books','create','','allow',NULL),('a7f45ddd-f428-4087-ae01-f3c5d404e6fb','p','global_user','books','update','','allow',NULL),('a883928b-55b8-4c4e-98d7-d197ce7d6e09','p','global_user','files','create','','allow',NULL),('ad5bc621-44b3-4455-ad99-22ffc5ead97b','g','owner','user','d39fd9a9-1477-4246-8370-a0e1625f3505',NULL,NULL,NULL),('b5560959-17ef-4923-84bf-b8227e517797','p','global_user','books','delete','','allow',NULL),('c10fd8ca-5c0a-4aa1-8c64-9b260b7f5b53','p','user','books','read','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('e3d9e9a9-b614-4b03-8b5c-8211f053e4e4','g','global_admin','global_user','',NULL,NULL,NULL),('e8054452-67ae-453b-8524-8d52e143c9be','p','user','books','create','d39fd9a9-1477-4246-8370-a0e1625f3505','allow',NULL),('ee9429c6-2284-46b0-95b6-df9646c5670c','g','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3','global_admin','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `casbin_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_fasilitas_bangunan`
--

DROP TABLE IF EXISTS `dat_fasilitas_bangunan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_fasilitas_bangunan` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `NO_BNG` int NOT NULL,
  `KD_FASILITAS` char(2) NOT NULL,
  `JML_SATUAN` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`NO_BNG`,`KD_FASILITAS`),
  KEY `fk_fas_master` (`KD_FASILITAS`),
  CONSTRAINT `fk_fas_bangunan` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`, `NO_BNG`) REFERENCES `dat_op_bangunan` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`, `NO_BNG`),
  CONSTRAINT `fk_fas_master` FOREIGN KEY (`KD_FASILITAS`) REFERENCES `fasilitas` (`KD_FASILITAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_fasilitas_bangunan`
--

LOCK TABLES `dat_fasilitas_bangunan` WRITE;
/*!40000 ALTER TABLE `dat_fasilitas_bangunan` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_fasilitas_bangunan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_legalitas_bumi`
--

DROP TABLE IF EXISTS `dat_legalitas_bumi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_legalitas_bumi` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `NO_LEGALITAS_TANAH` varchar(100) DEFAULT NULL,
  `JNS_LEGALITAS` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  CONSTRAINT `fk_legalitas_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_legalitas_bumi`
--

LOCK TABLES `dat_legalitas_bumi` WRITE;
/*!40000 ALTER TABLE `dat_legalitas_bumi` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_legalitas_bumi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_op_anggota`
--

DROP TABLE IF EXISTS `dat_op_anggota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_op_anggota` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `KD_PROPINSI_INDUK` char(2) NOT NULL,
  `KD_DATI2_INDUK` char(2) NOT NULL,
  `KD_KECAMATAN_INDUK` char(3) NOT NULL,
  `KD_KELURAHAN_INDUK` char(3) NOT NULL,
  `KD_BLOK_INDUK` char(3) NOT NULL,
  `NO_URUT_INDUK` char(4) NOT NULL,
  `KD_JNS_OP_INDUK` char(1) NOT NULL,
  `LUAS_BUMI_BEBAN` bigint DEFAULT NULL,
  `LUAS_BNG_BEBAN` bigint DEFAULT NULL,
  `NILAI_SISTEM_BUMI_BEBAN` bigint DEFAULT NULL,
  `NILAI_SISTEM_BNG_BEBAN` bigint DEFAULT NULL,
  `NJOP_BUMI_BEBAN` bigint DEFAULT NULL,
  `NJOP_BNG_BEBAN` bigint DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  CONSTRAINT `fk_anggota_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_op_anggota`
--

LOCK TABLES `dat_op_anggota` WRITE;
/*!40000 ALTER TABLE `dat_op_anggota` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_op_anggota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_op_bangunan`
--

DROP TABLE IF EXISTS `dat_op_bangunan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_op_bangunan` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `NO_BNG` int NOT NULL,
  `NO_FORMULIR_LSPOP` varchar(11) DEFAULT NULL,
  `JNS_TRANSAKSI_BNG` char(1) DEFAULT NULL,
  `KD_JPB` char(2) DEFAULT NULL,
  `LUAS_BNG` bigint NOT NULL DEFAULT '0',
  `JML_LANTAI_BNG` int NOT NULL DEFAULT '1',
  `THN_DIBANGUN_BNG` char(4) DEFAULT NULL,
  `THN_RENOVASI_BNG` char(4) DEFAULT NULL,
  `KONDISI_BNG` char(1) DEFAULT NULL,
  `JNS_KONSTRUKSI_BNG` char(1) DEFAULT NULL,
  `JNS_ATAP_BNG` char(1) DEFAULT NULL,
  `KD_DINDING` char(1) DEFAULT NULL,
  `KD_LANTAI` char(1) DEFAULT NULL,
  `KD_LANGIT_LANGIT` char(1) DEFAULT NULL,
  `TING_KOLOM_JPB3` bigint DEFAULT NULL,
  `LBR_BENT_JPB3` bigint DEFAULT NULL,
  `DAYA_DUKUNG_LANTAI_JPB3` bigint DEFAULT NULL,
  `KELILING_DINDING_JPB3` bigint DEFAULT NULL,
  `LUAS_MEZZANINE_JPB3` bigint DEFAULT NULL,
  `KLS_JPB2` bigint DEFAULT NULL,
  `KLS_JPB4` bigint DEFAULT NULL,
  `KLS_JPB5` bigint DEFAULT NULL,
  `KLS_JPB6` bigint DEFAULT NULL,
  `JNS_JPB7` char(1) DEFAULT NULL,
  `BINTANG_JPB7` tinyint DEFAULT NULL,
  `JML_KMR_JPB7` int DEFAULT NULL,
  `LUAS_KMR_JPB7_DGN_AC_SENT` decimal(12,2) DEFAULT NULL,
  `LUAS_KMR_LAIN_JPB7_DGN_AC_SENT` decimal(12,2) DEFAULT NULL,
  `KLS_JPB13` bigint DEFAULT NULL,
  `KLS_JPB16` bigint DEFAULT NULL,
  `NILAI_SISTEM_BNG` bigint NOT NULL DEFAULT '0',
  `NILAI_FORMULA` bigint DEFAULT NULL,
  `NILAI_INDIVIDU` bigint NOT NULL DEFAULT '0',
  `TGL_PENDATAAN_BNG` datetime DEFAULT NULL,
  `NM_PENDATAAN_OP` varchar(200) DEFAULT NULL,
  `NIP_PENDATA_BNG` varchar(30) DEFAULT NULL,
  `TGL_PEMERIKSAAN_BNG` datetime DEFAULT NULL,
  `NM_PEMERIKSAAN_OP_BNG` varchar(200) DEFAULT NULL,
  `NIP_PEMERIKSA_BNG` varchar(30) DEFAULT NULL,
  `TGL_KUNJUNGAN_KEMBALI` datetime DEFAULT NULL,
  `AKTIF` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`NO_BNG`),
  CONSTRAINT `fk_bangunan_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_op_bangunan`
--

LOCK TABLES `dat_op_bangunan` WRITE;
/*!40000 ALTER TABLE `dat_op_bangunan` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_op_bangunan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_op_induk`
--

DROP TABLE IF EXISTS `dat_op_induk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_op_induk` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  CONSTRAINT `fk_op_induk_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_op_induk`
--

LOCK TABLES `dat_op_induk` WRITE;
/*!40000 ALTER TABLE `dat_op_induk` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_op_induk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dat_subjek_pajak`
--

DROP TABLE IF EXISTS `dat_subjek_pajak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dat_subjek_pajak` (
  `SUBJEK_PAJAK_ID` varchar(30) NOT NULL,
  `NM_WP` varchar(30) NOT NULL,
  `JALAN_WP` varchar(100) NOT NULL,
  `BLOK_KAV_NO_WP` varchar(15) DEFAULT NULL,
  `RW_WP` varchar(2) DEFAULT NULL,
  `RT_WP` varchar(3) DEFAULT NULL,
  `KELURAHAN_WP` varchar(30) DEFAULT NULL,
  `KOTA_WP` varchar(30) DEFAULT NULL,
  `KD_POS_WP` varchar(5) DEFAULT NULL,
  `TELP_WP` varchar(20) DEFAULT NULL,
  `NPWP` varchar(16) DEFAULT NULL,
  `EMAIL_WP` varchar(100) DEFAULT NULL,
  `STATUS_PEKERJAAN_WP` char(1) NOT NULL,
  PRIMARY KEY (`SUBJEK_PAJAK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dat_subjek_pajak`
--

LOCK TABLES `dat_subjek_pajak` WRITE;
/*!40000 ALTER TABLE `dat_subjek_pajak` DISABLE KEYS */;
/*!40000 ALTER TABLE `dat_subjek_pajak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fasilitas`
--

DROP TABLE IF EXISTS `fasilitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fasilitas` (
  `KD_FASILITAS` char(2) NOT NULL,
  `NM_FASILITAS` varchar(63) NOT NULL,
  `SATUAN_FASILITAS` varchar(10) NOT NULL,
  `NILAI_FASILITAS` decimal(15,2) NOT NULL DEFAULT '0.00',
  `STATUS_FASILITAS` char(1) NOT NULL DEFAULT '1',
  `KETERGANTUNGAN` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`KD_FASILITAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fasilitas`
--

LOCK TABLES `fasilitas` WRITE;
/*!40000 ALTER TABLE `fasilitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `fasilitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_akses`
--

DROP TABLE IF EXISTS `group_akses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_akses` (
  `HAK_AKSES` varchar(20) NOT NULL,
  `AKSES` varchar(50) NOT NULL,
  PRIMARY KEY (`HAK_AKSES`,`AKSES`),
  KEY `fk_group_akses_akses` (`AKSES`),
  CONSTRAINT `fk_group_akses_akses` FOREIGN KEY (`AKSES`) REFERENCES `akses` (`AKSES`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_akses`
--

LOCK TABLES `group_akses` WRITE;
/*!40000 ALTER TABLE `group_akses` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_akses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `histori_mutasi`
--

DROP TABLE IF EXISTS `histori_mutasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `histori_mutasi` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NO_PELAYANAN` varchar(30) NOT NULL,
  `NOP_SEBELUM` varchar(18) DEFAULT NULL,
  `NAMA_SEBELUM` varchar(100) DEFAULT NULL,
  `LT_SEBELUM` decimal(12,2) DEFAULT NULL,
  `LB_SEBELUM` decimal(12,2) DEFAULT NULL,
  `PBB_SEBELUM` decimal(15,2) DEFAULT NULL,
  `NOP_SESUDAH` varchar(18) DEFAULT NULL,
  `NAMA_SESUDAH` varchar(100) DEFAULT NULL,
  `LT_SESUDAH` decimal(12,2) DEFAULT NULL,
  `LB_SESUDAH` decimal(12,2) DEFAULT NULL,
  `PBB_SESUDAH` decimal(15,2) DEFAULT NULL,
  `TGL_MUTASI` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `NIP_PETUGAS` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_histori_mutasi_pelayanan` (`NO_PELAYANAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `histori_mutasi`
--

LOCK TABLES `histori_mutasi` WRITE;
/*!40000 ALTER TABLE `histori_mutasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `histori_mutasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `histori_sppt`
--

DROP TABLE IF EXISTS `histori_sppt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `histori_sppt` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `THN_PAJAK_SPPT` year NOT NULL,
  `SIKLUS_SPPT` tinyint NOT NULL,
  `NJOP_BUMI` decimal(15,2) DEFAULT NULL,
  `NJOP_BNG` decimal(15,2) DEFAULT NULL,
  `NJOP_SPPT` decimal(15,2) DEFAULT NULL,
  `NJOPTKP_SPPT` decimal(15,2) DEFAULT NULL,
  `NJKP_SPPT` decimal(15,2) DEFAULT NULL,
  `PBB_TERHUTANG_SPPT` decimal(15,2) DEFAULT NULL,
  `FAKTOR_PENGURANG_SPPT` decimal(15,2) DEFAULT NULL,
  `PBB_YG_HARUS_DIBAYAR_SPPT` decimal(15,2) DEFAULT NULL,
  `TGL_PERUBAHAN` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `NIP_PETUGAS` varchar(40) DEFAULT NULL,
  `KETERANGAN` text,
  PRIMARY KEY (`ID`),
  KEY `idx_histori_nop` (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`THN_PAJAK_SPPT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `histori_sppt`
--

LOCK TABLES `histori_sppt` WRITE;
/*!40000 ALTER TABLE `histori_sppt` DISABLE KEYS */;
/*!40000 ALTER TABLE `histori_sppt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitation`
--

DROP TABLE IF EXISTS `invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitation` (
  `id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `team_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `inviter_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invitation_inviter_id_user_id_fk` (`inviter_id`),
  KEY `invitation_organizationId_idx` (`organization_id`),
  KEY `invitation_email_idx` (`email`),
  CONSTRAINT `invitation_inviter_id_user_id_fk` FOREIGN KEY (`inviter_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invitation_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitation`
--

LOCK TABLES `invitation` WRITE;
/*!40000 ALTER TABLE `invitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jalan`
--

DROP TABLE IF EXISTS `jalan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jalan` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `NM_JALAN` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_jalan_wilayah` (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jalan`
--

LOCK TABLES `jalan` WRITE;
/*!40000 ALTER TABLE `jalan` DISABLE KEYS */;
/*!40000 ALTER TABLE `jalan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jenis_sppt`
--

DROP TABLE IF EXISTS `jenis_sppt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jenis_sppt` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `KODE` varchar(10) NOT NULL,
  `NAMA` varchar(100) NOT NULL,
  `TARIF_KHUSUS` decimal(8,4) DEFAULT NULL,
  `AKTIF` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uk_jenis_sppt_kode` (`KODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jenis_sppt`
--

LOCK TABLES `jenis_sppt` WRITE;
/*!40000 ALTER TABLE `jenis_sppt` DISABLE KEYS */;
/*!40000 ALTER TABLE `jenis_sppt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelas_bangunan`
--

DROP TABLE IF EXISTS `kelas_bangunan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kelas_bangunan` (
  `KELAS_BANGUNAN` varchar(5) NOT NULL,
  `NILAI_MINIMUM` decimal(15,2) NOT NULL,
  `NILAI_MAKSIMUM` decimal(15,2) NOT NULL,
  `NJOP_BANGUNAN` decimal(15,2) NOT NULL,
  PRIMARY KEY (`KELAS_BANGUNAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas_bangunan`
--

LOCK TABLES `kelas_bangunan` WRITE;
/*!40000 ALTER TABLE `kelas_bangunan` DISABLE KEYS */;
/*!40000 ALTER TABLE `kelas_bangunan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelas_bumi`
--

DROP TABLE IF EXISTS `kelas_bumi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kelas_bumi` (
  `KELAS_BUMI` varchar(5) NOT NULL,
  `NILAI_MINIMUM` decimal(15,2) NOT NULL,
  `NILAI_MAKSIMUM` decimal(15,2) NOT NULL,
  `NJOP_BUMI` decimal(15,2) NOT NULL,
  PRIMARY KEY (`KELAS_BUMI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas_bumi`
--

LOCK TABLES `kelas_bumi` WRITE;
/*!40000 ALTER TABLE `kelas_bumi` DISABLE KEYS */;
/*!40000 ALTER TABLE `kelas_bumi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konfigurasi`
--

DROP TABLE IF EXISTS `konfigurasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `konfigurasi` (
  `NAMA` varchar(100) NOT NULL,
  `NILAI` longblob,
  PRIMARY KEY (`NAMA`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konfigurasi`
--

LOCK TABLES `konfigurasi` WRITE;
/*!40000 ALTER TABLE `konfigurasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `konfigurasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_aktivitas`
--

DROP TABLE IF EXISTS `log_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_aktivitas` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(20) NOT NULL,
  `AKSI` varchar(50) NOT NULL,
  `MODUL` varchar(50) DEFAULT NULL,
  `KETERANGAN` text,
  `IP_ADDRESS` varchar(45) DEFAULT NULL,
  `CREATED_AT` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `idx_log_user` (`USERNAME`),
  KEY `idx_log_tgl` (`CREATED_AT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_aktivitas`
--

LOCK TABLES `log_aktivitas` WRITE;
/*!40000 ALTER TABLE `log_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_delete_pelayanan`
--

DROP TABLE IF EXISTS `log_delete_pelayanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_delete_pelayanan` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NO_PELAYANAN` varchar(30) NOT NULL,
  `DATA_SNAPSHOT` json DEFAULT NULL,
  `DIHAPUS_OLEH` varchar(20) DEFAULT NULL,
  `TGL_HAPUS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ALASAN` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_delete_pelayanan`
--

LOCK TABLES `log_delete_pelayanan` WRITE;
/*!40000 ALTER TABLE `log_delete_pelayanan` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_delete_pelayanan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `HAK_AKSES` varchar(20) NOT NULL,
  `NIP` varchar(30) DEFAULT NULL,
  `NAMA` varchar(200) DEFAULT NULL,
  `JABATAN` varchar(200) DEFAULT NULL,
  `PENANGGUNG_JAWAB_CETAK` tinyint NOT NULL DEFAULT '0',
  `TANDA_TANGAN` longblob,
  `STATUS_AKTIF` tinyint NOT NULL DEFAULT '1',
  `LAST_LOGIN` datetime DEFAULT NULL,
  `FAILED_ATTEMPTS` tinyint NOT NULL DEFAULT '0',
  `LOCKED_UNTIL` datetime DEFAULT NULL,
  `CREATED_AT` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `USER_ID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uk_username` (`USERNAME`),
  KEY `login_USER_ID_user_id_fk` (`USER_ID`),
  CONSTRAINT `login_USER_ID_user_id_fk` FOREIGN KEY (`USER_ID`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'member',
  `custom_role_id` varchar(36) DEFAULT NULL,
  `created_at` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_organizationId_idx` (`organization_id`),
  KEY `member_userId_idx` (`user_id`),
  KEY `member_custom_role_id_idx` (`custom_role_id`),
  CONSTRAINT `member_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE,
  CONSTRAINT `member_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('b926a194-97e3-49df-b866-5304f76409d2','d39fd9a9-1477-4246-8370-a0e1625f3505','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3','owner',NULL,'2026-03-25 01:55:49.374');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_roles`
--

DROP TABLE IF EXISTS `member_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_roles` (
  `id` varchar(36) NOT NULL,
  `member_id` varchar(36) NOT NULL,
  `role_id` varchar(36) NOT NULL,
  `role_type` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `created_by` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_member_role` (`member_id`,`role_id`,`role_type`),
  KEY `member_roles_created_by_user_id_fk` (`created_by`),
  KEY `member_roles_member_id_idx` (`member_id`),
  KEY `member_roles_role_id_idx` (`role_id`),
  CONSTRAINT `member_roles_created_by_user_id_fk` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `member_roles_member_id_member_id_fk` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_roles`
--

LOCK TABLES `member_roles` WRITE;
/*!40000 ALTER TABLE `member_roles` DISABLE KEYS */;
INSERT INTO `member_roles` VALUES ('38d8234e-a201-41b7-b0ae-8bed9dfa91a5','b926a194-97e3-49df-b866-5304f76409d2','owner','system','2026-03-25 08:55:49','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3');
/*!40000 ALTER TABLE `member_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_preferences`
--

DROP TABLE IF EXISTS `notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_preferences` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `in_app_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `toasts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `success_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `warning_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `error_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `info_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_preferences_userId_idx` (`user_id`),
  CONSTRAINT `notification_preferences_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences`
--

LOCK TABLES `notification_preferences` WRITE;
/*!40000 ALTER TABLE `notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'info',
  `link` text,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `notifications_userId_idx` (`user_id`),
  KEY `notifications_createdAt_idx` (`created_at`),
  CONSTRAINT `notifications_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('eded8298-541f-47d2-9c65-7690f221fbfe','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3','Real-time Test Alert','This successful test notification was triggered via oRPC! SSE is working beautifully using native Next.js 16 WebStreams.','success',NULL,1,'2026-03-25 02:14:12');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_token`
--

DROP TABLE IF EXISTS `oauth_access_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_token` (
  `id` varchar(36) NOT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `access_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `refresh_token_expires_at` timestamp(3) NULL DEFAULT NULL,
  `client_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `scopes` text,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_access_token_access_token_unique` (`access_token`),
  UNIQUE KEY `oauth_access_token_refresh_token_unique` (`refresh_token`),
  KEY `oauthAccessToken_clientId_idx` (`client_id`),
  KEY `oauthAccessToken_userId_idx` (`user_id`),
  CONSTRAINT `oauth_access_token_client_id_oauth_application_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `oauth_application` (`client_id`) ON DELETE CASCADE,
  CONSTRAINT `oauth_access_token_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_token`
--

LOCK TABLES `oauth_access_token` WRITE;
/*!40000 ALTER TABLE `oauth_access_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_application`
--

DROP TABLE IF EXISTS `oauth_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_application` (
  `id` varchar(36) NOT NULL,
  `name` text,
  `icon` text,
  `metadata` text,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` text,
  `redirect_urls` text,
  `type` text,
  `disabled` tinyint(1) DEFAULT '0',
  `user_id` varchar(36) DEFAULT NULL,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_application_client_id_unique` (`client_id`),
  KEY `oauthApplication_userId_idx` (`user_id`),
  CONSTRAINT `oauth_application_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_application`
--

LOCK TABLES `oauth_application` WRITE;
/*!40000 ALTER TABLE `oauth_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consent`
--

DROP TABLE IF EXISTS `oauth_consent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consent` (
  `id` varchar(36) NOT NULL,
  `client_id` varchar(36) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL,
  `scopes` text,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  `consent_given` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauthConsent_clientId_idx` (`client_id`),
  KEY `oauthConsent_userId_idx` (`user_id`),
  CONSTRAINT `oauth_consent_client_id_oauth_application_client_id_fk` FOREIGN KEY (`client_id`) REFERENCES `oauth_application` (`client_id`) ON DELETE CASCADE,
  CONSTRAINT `oauth_consent_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consent`
--

LOCK TABLES `oauth_consent` WRITE;
/*!40000 ALTER TABLE `oauth_consent` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `org_roles`
--

DROP TABLE IF EXISTS `org_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_roles` (
  `id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text,
  `is_default_role` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()),
  `created_by` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `org_roles_org_slug_idx` (`organization_id`,`slug`),
  KEY `org_roles_org_idx` (`organization_id`),
  KEY `org_roles_created_by_idx` (`created_by`),
  CONSTRAINT `org_roles_created_by_user_id_fk` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `org_roles_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org_roles`
--

LOCK TABLES `org_roles` WRITE;
/*!40000 ALTER TABLE `org_roles` DISABLE KEYS */;
INSERT INTO `org_roles` VALUES ('b91fd088-0840-42b7-957e-b3ff406445d7','d39fd9a9-1477-4246-8370-a0e1625f3505','User','user','Default member role with standard permissions',1,'2026-03-25 01:55:49','2026-03-25 01:55:49','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3');
/*!40000 ALTER TABLE `org_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `logo` text,
  `created_at` timestamp(3) NOT NULL,
  `metadata` text,
  `auto_join` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_slug_unique` (`slug`),
  UNIQUE KEY `organization_slug_uidx` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES ('d39fd9a9-1477-4246-8370-a0e1625f3505','Default Organization','default-org',NULL,'2026-03-25 01:55:49.368',NULL,1);
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelayanan`
--

DROP TABLE IF EXISTS `pelayanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelayanan` (
  `NO_PELAYANAN` varchar(30) NOT NULL,
  `KD_PROPINSI` char(2) DEFAULT NULL,
  `KD_DATI2` char(2) DEFAULT NULL,
  `KD_KECAMATAN` char(3) DEFAULT NULL,
  `KD_KELURAHAN` char(3) DEFAULT NULL,
  `KD_BLOK` char(3) DEFAULT NULL,
  `NO_URUT` char(4) DEFAULT NULL,
  `KD_JNS_OP` char(1) DEFAULT NULL,
  `KD_JNS_PELAYANAN` char(2) NOT NULL,
  `TANGGAL_PELAYANAN` date NOT NULL,
  `TANGGAL_PERKIRAAN_SELESAI` date DEFAULT NULL,
  `NAMA_PEMOHON` varchar(100) DEFAULT NULL,
  `ALAMAT_PEMOHON` text,
  `LETAK_OP` varchar(200) DEFAULT NULL,
  `KECAMATAN` varchar(50) DEFAULT NULL,
  `KELURAHAN` varchar(50) DEFAULT NULL,
  `STATUS_PELAYANAN` smallint NOT NULL DEFAULT '1',
  `NIP_PETUGAS_PENERIMA` varchar(40) DEFAULT NULL,
  `NAMA_PETUGAS_PENERIMA` varchar(100) DEFAULT NULL,
  `NIP_AR` varchar(40) DEFAULT NULL,
  `NAMA_AR` varchar(100) DEFAULT NULL,
  `CATATAN` text,
  `KETERANGAN` text,
  `TGL_MASUK_PENILAI` date DEFAULT NULL,
  `NIP_MASUK_PENILAI` varchar(40) DEFAULT NULL,
  `TGL_MASUK_PENETAPAN` date DEFAULT NULL,
  `NIP_MASUK_PENETAPAN` varchar(40) DEFAULT NULL,
  `TGL_SELESAI` date DEFAULT NULL,
  `NIP_SELESAI` varchar(40) DEFAULT NULL,
  `TGL_TERKONFIRMASI_WP` date DEFAULT NULL,
  `NIP_TERKONFIRMASI_WP` varchar(40) DEFAULT NULL,
  `TGL_BERKAS_DITUNDA` date DEFAULT NULL,
  `ALASAN_DITUNDA` text,
  `IS_KOLEKTIF` tinyint NOT NULL DEFAULT '0',
  `TTD_KIRI_JABATAN` varchar(100) DEFAULT NULL,
  `TTD_KIRI_NAMA` varchar(100) DEFAULT NULL,
  `TTD_KIRI_NIP` varchar(40) DEFAULT NULL,
  `TTD_KANAN_JABATAN` varchar(100) DEFAULT NULL,
  `TTD_KANAN_NAMA` varchar(100) DEFAULT NULL,
  `TTD_KANAN_NIP` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`NO_PELAYANAN`),
  KEY `fk_pelayanan_jns` (`KD_JNS_PELAYANAN`),
  KEY `idx_pelayanan_nop` (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  KEY `idx_pelayanan_status` (`STATUS_PELAYANAN`),
  KEY `idx_pelayanan_tgl` (`TANGGAL_PELAYANAN`),
  CONSTRAINT `fk_pelayanan_jns` FOREIGN KEY (`KD_JNS_PELAYANAN`) REFERENCES `ref_jns_pelayanan` (`KD_JNS_PELAYANAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelayanan`
--

LOCK TABLES `pelayanan` WRITE;
/*!40000 ALTER TABLE `pelayanan` DISABLE KEYS */;
/*!40000 ALTER TABLE `pelayanan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelayanan_dokumen`
--

DROP TABLE IF EXISTS `pelayanan_dokumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelayanan_dokumen` (
  `NO_PELAYANAN` varchar(30) NOT NULL,
  `DOKUMEN_ID` tinyint NOT NULL,
  PRIMARY KEY (`NO_PELAYANAN`,`DOKUMEN_ID`),
  CONSTRAINT `fk_dok_pelayanan` FOREIGN KEY (`NO_PELAYANAN`) REFERENCES `pelayanan` (`NO_PELAYANAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelayanan_dokumen`
--

LOCK TABLES `pelayanan_dokumen` WRITE;
/*!40000 ALTER TABLE `pelayanan_dokumen` DISABLE KEYS */;
/*!40000 ALTER TABLE `pelayanan_dokumen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelayanan_lampiran_kolektif`
--

DROP TABLE IF EXISTS `pelayanan_lampiran_kolektif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelayanan_lampiran_kolektif` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NO_PELAYANAN` varchar(30) NOT NULL,
  `NOP` varchar(18) DEFAULT NULL,
  `NAMA` varchar(100) DEFAULT NULL,
  `ALAMAT` text,
  `LT` decimal(12,2) DEFAULT NULL,
  `LB` decimal(12,2) DEFAULT NULL,
  `KETERANGAN` text,
  PRIMARY KEY (`ID`),
  KEY `idx_lamp_kol_pelayanan` (`NO_PELAYANAN`),
  CONSTRAINT `fk_lamp_kol_pelayanan` FOREIGN KEY (`NO_PELAYANAN`) REFERENCES `pelayanan` (`NO_PELAYANAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelayanan_lampiran_kolektif`
--

LOCK TABLES `pelayanan_lampiran_kolektif` WRITE;
/*!40000 ALTER TABLE `pelayanan_lampiran_kolektif` DISABLE KEYS */;
/*!40000 ALTER TABLE `pelayanan_lampiran_kolektif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembayaran_sppt`
--

DROP TABLE IF EXISTS `pembayaran_sppt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembayaran_sppt` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `THN_PAJAK_SPPT` year NOT NULL,
  `PEMBAYARAN_KE` tinyint NOT NULL,
  `TGL_PEMBAYARAN_SPPT` date NOT NULL,
  `JML_SPPT_YG_DIBAYAR` decimal(15,2) NOT NULL DEFAULT '0.00',
  `DENDA_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `JML_BAYAR` decimal(15,2) NOT NULL DEFAULT '0.00',
  `NAMA_BAYAR` varchar(100) DEFAULT NULL,
  `CHANNEL_PEMBAYARAN` varchar(50) DEFAULT NULL,
  `NO_REFERENSI` varchar(100) DEFAULT NULL,
  `NIP_PETUGAS` varchar(40) DEFAULT NULL,
  `DIBATALKAN` tinyint NOT NULL DEFAULT '0',
  `TGL_BATAL` datetime DEFAULT NULL,
  `ALASAN_BATAL` text,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`THN_PAJAK_SPPT`,`PEMBAYARAN_KE`),
  CONSTRAINT `fk_pembayaran_sppt` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`, `THN_PAJAK_SPPT`) REFERENCES `sppt` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`, `THN_PAJAK_SPPT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembayaran_sppt`
--

LOCK TABLES `pembayaran_sppt` WRITE;
/*!40000 ALTER TABLE `pembayaran_sppt` DISABLE KEYS */;
/*!40000 ALTER TABLE `pembayaran_sppt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pemekaran`
--

DROP TABLE IF EXISTS `pemekaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pemekaran` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `NAMA_PEMEKARAN` varchar(100) NOT NULL,
  `TGL_BERLAKU` date NOT NULL,
  `KETERANGAN` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pemekaran`
--

LOCK TABLES `pemekaran` WRITE;
/*!40000 ALTER TABLE `pemekaran` DISABLE KEYS */;
/*!40000 ALTER TABLE `pemekaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pemekaran_detail`
--

DROP TABLE IF EXISTS `pemekaran_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pemekaran_detail` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `PEMEKARAN_ID` int NOT NULL,
  `KD_PROPINSI_LAMA` char(2) NOT NULL,
  `KD_DATI2_LAMA` char(2) NOT NULL,
  `KD_KECAMATAN_LAMA` char(3) NOT NULL,
  `KD_KELURAHAN_LAMA` char(3) NOT NULL,
  `KD_BLOK_LAMA` char(3) NOT NULL,
  `NO_URUT_LAMA` char(4) NOT NULL,
  `KD_JNS_OP_LAMA` char(1) NOT NULL,
  `KD_PROPINSI_BARU` char(2) NOT NULL,
  `KD_DATI2_BARU` char(2) NOT NULL,
  `KD_KECAMATAN_BARU` char(3) NOT NULL,
  `KD_KELURAHAN_BARU` char(3) NOT NULL,
  `KD_BLOK_BARU` char(3) NOT NULL,
  `NO_URUT_BARU` char(4) NOT NULL,
  `KD_JNS_OP_BARU` char(1) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_pemekaran_detail_induk` (`PEMEKARAN_ID`),
  KEY `idx_pemekaran_nop_lama` (`KD_PROPINSI_LAMA`,`KD_DATI2_LAMA`,`KD_KECAMATAN_LAMA`,`KD_KELURAHAN_LAMA`,`KD_BLOK_LAMA`,`NO_URUT_LAMA`,`KD_JNS_OP_LAMA`),
  CONSTRAINT `fk_pemekaran_detail_induk` FOREIGN KEY (`PEMEKARAN_ID`) REFERENCES `pemekaran` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pemekaran_detail`
--

LOCK TABLES `pemekaran_detail` WRITE;
/*!40000 ALTER TABLE `pemekaran_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `pemekaran_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_dati2`
--

DROP TABLE IF EXISTS `ref_dati2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_dati2` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `NM_DATI2` varchar(30) NOT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`),
  CONSTRAINT `fk_dati2_propinsi` FOREIGN KEY (`KD_PROPINSI`) REFERENCES `ref_propinsi` (`KD_PROPINSI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_dati2`
--

LOCK TABLES `ref_dati2` WRITE;
/*!40000 ALTER TABLE `ref_dati2` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_dati2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_jns_pelayanan`
--

DROP TABLE IF EXISTS `ref_jns_pelayanan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_jns_pelayanan` (
  `KD_JNS_PELAYANAN` char(2) NOT NULL,
  `NM_JENIS_PELAYANAN` varchar(100) NOT NULL,
  PRIMARY KEY (`KD_JNS_PELAYANAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_jns_pelayanan`
--

LOCK TABLES `ref_jns_pelayanan` WRITE;
/*!40000 ALTER TABLE `ref_jns_pelayanan` DISABLE KEYS */;
INSERT INTO `ref_jns_pelayanan` VALUES ('01','Pendaftaran Data Baru'),('02','Mutasi Objek/Subjek'),('03','Pembetulan SPPT/SKP/STP'),('04','Pembatalan SPPT/SKP'),('05','Salinan SPPT/SKP'),('06','Keberatan Penunjukan Wajib Pajak'),('07','Keberatan Atas Pajak Terhutang'),('08','Pengurangan Atas Besarnya Pajak Terhutang'),('09','Restitusi dan Kompensasi'),('10','Pengurangan Denda Administrasi'),('11','Penentuan Kembali Tanggal Jatuh Tempo'),('12','Penundaan Tanggal Jatuh Tempo SPOP'),('13','PEMBERIAN INFORMASI PBB'),('14','PEMBETULAN SK KEBERATAN'),('15','MUTASI PEMECAHAN');
/*!40000 ALTER TABLE `ref_jns_pelayanan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_kategori`
--

DROP TABLE IF EXISTS `ref_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_kategori` (
  `KATEGORI` varchar(100) NOT NULL,
  `KODE` char(2) NOT NULL,
  `NAMA` varchar(100) NOT NULL,
  PRIMARY KEY (`KATEGORI`,`KODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_kategori`
--

LOCK TABLES `ref_kategori` WRITE;
/*!40000 ALTER TABLE `ref_kategori` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_kecamatan`
--

DROP TABLE IF EXISTS `ref_kecamatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_kecamatan` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `NM_KECAMATAN` varchar(30) DEFAULT NULL,
  `NM_KECAMATAN_ONLY` varchar(30) NOT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`),
  CONSTRAINT `fk_kecamatan_dati2` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`) REFERENCES `ref_dati2` (`KD_PROPINSI`, `KD_DATI2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_kecamatan`
--

LOCK TABLES `ref_kecamatan` WRITE;
/*!40000 ALTER TABLE `ref_kecamatan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_kecamatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_kelurahan`
--

DROP TABLE IF EXISTS `ref_kelurahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_kelurahan` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_SEKTOR` char(2) NOT NULL DEFAULT '00',
  `NM_KELURAHAN` varchar(30) DEFAULT NULL,
  `NM_KELURAHAN_ONLY` varchar(30) NOT NULL,
  `NO_KELURAHAN` smallint DEFAULT NULL,
  `KD_POS_KELURAHAN` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_SEKTOR`),
  CONSTRAINT `fk_kelurahan_kecamatan` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`) REFERENCES `ref_kecamatan` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_kelurahan`
--

LOCK TABLES `ref_kelurahan` WRITE;
/*!40000 ALTER TABLE `ref_kelurahan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_kelurahan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ref_propinsi`
--

DROP TABLE IF EXISTS `ref_propinsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_propinsi` (
  `KD_PROPINSI` char(2) NOT NULL,
  `NM_PROPINSI` varchar(30) NOT NULL,
  PRIMARY KEY (`KD_PROPINSI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_propinsi`
--

LOCK TABLES `ref_propinsi` WRITE;
/*!40000 ALTER TABLE `ref_propinsi` DISABLE KEYS */;
/*!40000 ALTER TABLE `ref_propinsi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_ownership`
--

DROP TABLE IF EXISTS `resource_ownership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resource_ownership` (
  `id` varchar(36) NOT NULL,
  `resource_type` varchar(100) NOT NULL,
  `resource_id` varchar(36) NOT NULL,
  `owner_id` varchar(36) NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `resource_ownership_unique_idx` (`resource_type`,`resource_id`,`owner_id`),
  KEY `resource_ownership_resource_idx` (`resource_type`,`resource_id`),
  KEY `resource_ownership_owner_idx` (`owner_id`),
  KEY `resource_ownership_org_idx` (`organization_id`),
  CONSTRAINT `resource_ownership_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_ownership`
--

LOCK TABLES `resource_ownership` WRITE;
/*!40000 ALTER TABLE `resource_ownership` DISABLE KEYS */;
/*!40000 ALTER TABLE `resource_ownership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` varchar(36) NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL,
  `ip_address` text,
  `user_agent` text,
  `user_id` varchar(36) NOT NULL,
  `impersonated_by` text,
  `active_organization_id` text,
  `active_team_id` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token_unique` (`token`),
  KEY `session_userId_idx` (`user_id`),
  CONSTRAINT `session_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('pdqn4pyikqZGumNqVQYTg9tMIHr4nY4t','2026-04-01 02:33:23.145','ESnQX2GQ39YyNbLr2Gx7Sn5kIjupnmKV','2026-03-25 02:33:23.146','2026-03-25 02:33:24.547','0000:0000:0000:0000:0000:0000:0000:0000','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','d4bd01bd-d3d2-40c1-bf43-fd54c79829d3',NULL,'d39fd9a9-1477-4246-8370-a0e1625f3505',NULL);
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spop`
--

DROP TABLE IF EXISTS `spop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spop` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `SUBJEK_PAJAK_ID` varchar(30) NOT NULL,
  `NO_FORMULIR_SPOP` varchar(50) DEFAULT NULL,
  `JNS_TRANSAKSI_OP` char(1) NOT NULL,
  `KD_PROPINSI_BERSAMA` char(2) DEFAULT NULL,
  `KD_DATI2_BERSAMA` char(2) DEFAULT NULL,
  `KD_KECAMATAN_BERSAMA` char(3) DEFAULT NULL,
  `KD_KELURAHAN_BERSAMA` char(3) DEFAULT NULL,
  `KD_BLOK_BERSAMA` char(3) DEFAULT NULL,
  `NO_URUT_BERSAMA` char(4) DEFAULT NULL,
  `KD_JNS_OP_BERSAMA` char(1) DEFAULT NULL,
  `KD_PROPINSI_ASAL` char(2) DEFAULT NULL,
  `KD_DATI2_ASAL` char(2) DEFAULT NULL,
  `KD_KECAMATAN_ASAL` char(3) DEFAULT NULL,
  `KD_KELURAHAN_ASAL` char(3) DEFAULT NULL,
  `KD_BLOK_ASAL` char(3) DEFAULT NULL,
  `NO_URUT_ASAL` char(4) DEFAULT NULL,
  `KD_JNS_OP_ASAL` char(1) DEFAULT NULL,
  `NO_SPPT_LAMA` char(4) DEFAULT NULL,
  `JALAN_OP` varchar(100) NOT NULL,
  `BLOK_KAV_NO_OP` varchar(15) DEFAULT NULL,
  `RT_OP` varchar(3) DEFAULT NULL,
  `RW_OP` varchar(2) DEFAULT NULL,
  `KELURAHAN_OP` varchar(30) DEFAULT NULL,
  `KD_STATUS_WP` char(1) NOT NULL,
  `LUAS_BUMI` bigint NOT NULL,
  `KD_ZNT` char(2) DEFAULT NULL,
  `JNS_BUMI` char(1) NOT NULL,
  `NILAI_SISTEM_BUMI` bigint NOT NULL,
  `TGL_PENDATAAN_OP` datetime NOT NULL,
  `NM_PENDATAAN_OP` varchar(100) DEFAULT NULL,
  `NIP_PENDATA` varchar(40) DEFAULT NULL,
  `TGL_PEMERIKSAAN_OP` datetime NOT NULL,
  `NM_PEMERIKSAAN_OP` varchar(100) DEFAULT NULL,
  `NIP_PEMERIKSA_OP` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  KEY `fk_spop_subjek` (`SUBJEK_PAJAK_ID`),
  CONSTRAINT `fk_spop_subjek` FOREIGN KEY (`SUBJEK_PAJAK_ID`) REFERENCES `dat_subjek_pajak` (`SUBJEK_PAJAK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spop`
--

LOCK TABLES `spop` WRITE;
/*!40000 ALTER TABLE `spop` DISABLE KEYS */;
/*!40000 ALTER TABLE `spop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sppt`
--

DROP TABLE IF EXISTS `sppt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sppt` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `THN_PAJAK_SPPT` year NOT NULL,
  `SIKLUS_SPPT` tinyint NOT NULL DEFAULT '1',
  `KD_JNS_SPPT` int DEFAULT NULL,
  `KD_KLS_TANAH` varchar(5) DEFAULT NULL,
  `KD_KLS_BNG` varchar(5) DEFAULT NULL,
  `TGL_JATUH_TEMPO` date DEFAULT NULL,
  `TGL_TERBIT` date DEFAULT NULL,
  `TGL_CETAK` date DEFAULT NULL,
  `LUAS_BUMI` decimal(12,2) NOT NULL DEFAULT '0.00',
  `LUAS_BNG` decimal(12,2) NOT NULL DEFAULT '0.00',
  `NJOP_BUMI` decimal(15,2) NOT NULL DEFAULT '0.00',
  `NJOP_BNG` decimal(15,2) NOT NULL DEFAULT '0.00',
  `NJOP_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `NJOPTKP_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `NJKP_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `PBB_TERHUTANG_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `FAKTOR_PENGURANG_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `PBB_YG_HARUS_DIBAYAR_SPPT` decimal(15,2) NOT NULL DEFAULT '0.00',
  `STATUS_PEMBAYARAN_SPPT` char(1) NOT NULL DEFAULT '0',
  `STATUS_TAGIHAN_SPPT` char(1) NOT NULL DEFAULT '0',
  `STATUS_CETAK_SPPT` char(1) NOT NULL DEFAULT '0',
  `STATUS_PEMBATALAN` char(1) NOT NULL DEFAULT '0',
  `NM_WP` varchar(30) DEFAULT NULL,
  `JALAN_WP` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`THN_PAJAK_SPPT`),
  KEY `idx_sppt_status_bayar` (`STATUS_PEMBAYARAN_SPPT`),
  KEY `idx_sppt_thn` (`THN_PAJAK_SPPT`),
  CONSTRAINT `fk_sppt_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sppt`
--

LOCK TABLES `sppt` WRITE;
/*!40000 ALTER TABLE `sppt` DISABLE KEYS */;
/*!40000 ALTER TABLE `sppt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sppt_khusus`
--

DROP TABLE IF EXISTS `sppt_khusus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sppt_khusus` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `JENIS_SPPT` int NOT NULL,
  `KETERANGAN` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`),
  KEY `fk_sppt_khusus_jenis` (`JENIS_SPPT`),
  CONSTRAINT `fk_sppt_khusus_jenis` FOREIGN KEY (`JENIS_SPPT`) REFERENCES `jenis_sppt` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sppt_khusus`
--

LOCK TABLES `sppt_khusus` WRITE;
/*!40000 ALTER TABLE `sppt_khusus` DISABLE KEYS */;
/*!40000 ALTER TABLE `sppt_khusus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_pbb`
--

DROP TABLE IF EXISTS `status_pbb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_pbb` (
  `KD_PROPINSI` char(2) NOT NULL,
  `KD_DATI2` char(2) NOT NULL,
  `KD_KECAMATAN` char(3) NOT NULL,
  `KD_KELURAHAN` char(3) NOT NULL,
  `KD_BLOK` char(3) NOT NULL,
  `NO_URUT` char(4) NOT NULL,
  `KD_JNS_OP` char(1) NOT NULL,
  `TAHUN_PBB` char(4) NOT NULL,
  `TANGGAL_BAYAR` datetime DEFAULT NULL,
  `PERMOHONAN_PENGURANGAN` double DEFAULT NULL,
  `PENGURANGAN_DIBERI` double DEFAULT NULL,
  `ALASAN_PENGURANGAN` longtext,
  `ALASAN_KEBERATAN` longtext,
  `NO_SK_PENGURANGAN` varchar(100) DEFAULT NULL,
  `TGL_SK` date DEFAULT NULL,
  PRIMARY KEY (`KD_PROPINSI`,`KD_DATI2`,`KD_KECAMATAN`,`KD_KELURAHAN`,`KD_BLOK`,`NO_URUT`,`KD_JNS_OP`,`TAHUN_PBB`),
  CONSTRAINT `fk_status_pbb_spop` FOREIGN KEY (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`) REFERENCES `spop` (`KD_PROPINSI`, `KD_DATI2`, `KD_KECAMATAN`, `KD_KELURAHAN`, `KD_BLOK`, `NO_URUT`, `KD_JNS_OP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_pbb`
--

LOCK TABLES `status_pbb` WRITE;
/*!40000 ALTER TABLE `status_pbb` DISABLE KEYS */;
/*!40000 ALTER TABLE `status_pbb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarif`
--

DROP TABLE IF EXISTS `tarif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarif` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `THN_AWAL` year NOT NULL,
  `THN_AKHIR` year DEFAULT NULL,
  `NJOP_MIN` decimal(15,2) NOT NULL,
  `NJOP_MAX` decimal(15,2) NOT NULL,
  `NILAI_TARIF` decimal(8,4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarif`
--

LOCK TABLES `tarif` WRITE;
/*!40000 ALTER TABLE `tarif` DISABLE KEYS */;
/*!40000 ALTER TABLE `tarif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` varchar(36) NOT NULL,
  `name` text NOT NULL,
  `organization_id` varchar(36) NOT NULL,
  `created_at` timestamp(3) NOT NULL,
  `updated_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_organizationId_idx` (`organization_id`),
  CONSTRAINT `team_organization_id_organization_id_fk` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_member`
--

DROP TABLE IF EXISTS `team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_member` (
  `id` varchar(36) NOT NULL,
  `team_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `created_at` timestamp(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teamMember_teamId_idx` (`team_id`),
  KEY `teamMember_userId_idx` (`user_id`),
  CONSTRAINT `team_member_team_id_team_id_fk` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_member_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_member`
--

LOCK TABLES `team_member` WRITE;
/*!40000 ALTER TABLE `team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor`
--

DROP TABLE IF EXISTS `two_factor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor` (
  `id` varchar(36) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `backup_codes` text NOT NULL,
  `user_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `twoFactor_secret_idx` (`secret`),
  KEY `twoFactor_userId_idx` (`user_id`),
  CONSTRAINT `two_factor_user_id_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor`
--

LOCK TABLES `two_factor` WRITE;
/*!40000 ALTER TABLE `two_factor` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `image` text,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL DEFAULT (now()),
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `display_username` text,
  `phone_number` varchar(255) DEFAULT NULL,
  `phone_number_verified` tinyint(1) DEFAULT NULL,
  `role` text,
  `banned` tinyint(1) DEFAULT '0',
  `ban_reason` text,
  `ban_expires` timestamp(3) NULL DEFAULT NULL,
  `is_anonymous` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_email_unique` (`email`),
  UNIQUE KEY `user_username_unique` (`username`),
  UNIQUE KEY `user_phone_number_unique` (`phone_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('d4bd01bd-d3d2-40c1-bf43-fd54c79829d3','Admin User','admin@example.com',1,NULL,'2026-03-25 01:55:49.352','2026-03-25 01:55:49.353',0,NULL,NULL,NULL,NULL,'admin',0,NULL,NULL,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification`
--

DROP TABLE IF EXISTS `verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification` (
  `id` varchar(36) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `expires_at` timestamp(3) NOT NULL,
  `created_at` timestamp(3) NOT NULL DEFAULT (now()),
  `updated_at` timestamp(3) NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  KEY `verification_identifier_idx` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification`
--

LOCK TABLES `verification` WRITE;
/*!40000 ALTER TABLE `verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-25 16:36:38
